export default function Footer() {
  return (
    <footer className="bg-black text-cream px-[5vw] py-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
      <div>
        <p className="font-serif text-xl text-cream mb-1">
          Dé<span className="text-gold">.</span>Oscar
        </p>
        <p className="text-[0.7rem] tracking-widest uppercase text-cream/40">
          Sydney, Australia
        </p>
      </div>
      <div className="flex gap-8 text-[0.7rem] tracking-widest uppercase text-cream/60">
        <a href="/#collections" className="hover:text-gold transition-colors">
          Collections
        </a>
        <a href="/#colour" className="hover:text-gold transition-colors">
          Colour Guide
        </a>
        <a href="/#accessories" className="hover:text-gold transition-colors">
          Accessories
        </a>
        <a href="/#contact" className="hover:text-gold transition-colors">
          Contact
        </a>
        <a
          href="https://www.instagram.com/de.oscarhairdresser/"
          target="_blank"
          rel="noopener noreferrer"
          className="hover:text-gold transition-colors"
        >
          Instagram
        </a>
        <a
          href="https://wa.me/61450670239"
          target="_blank"
          rel="noopener noreferrer"
          className="hover:text-gold transition-colors"
        >
          WhatsApp
        </a>
      </div>
      <p className="text-[0.65rem] text-cream/30">
        © {new Date().getFullYear()} Dé.Oscar Hair Extensions. All rights reserved.
      </p>
    </footer>
  );
}
