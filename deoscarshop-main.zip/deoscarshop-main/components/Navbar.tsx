"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { ShoppingBag, Menu, X } from "lucide-react";
import { useCart } from "@/context/CartContext";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { count, openCart } = useCart();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-[100] flex items-center justify-between px-[4vw] py-[1.1rem] transition-colors duration-300 ${
        scrolled ? "bg-black/95 backdrop-blur-md" : "bg-black/40"
      }`}
    >
      <Link href="/" className="font-serif text-2xl text-cream tracking-wide">
        Dé<span className="text-gold">.</span>Oscar
      </Link>

      <ul className="hidden md:flex items-center gap-10 list-none">
        <li>
          <Link href="/produtos" className="nav-link">
            Collections
          </Link>
        </li>
        <li>
          <a href="/#why" className="nav-link">
            Why Us
          </a>
        </li>
        <li>
          <a href="/#colour" className="nav-link">
            Colours
          </a>
        </li>
        <li>
          <a href="/#accessories" className="nav-link">
            Accessories
          </a>
        </li>
        <li>
          <a href="/#contact" className="nav-link">
            Contact
          </a>
        </li>
        <li>
          <a
            href="https://wa.me/61450670239"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-gold !text-black px-5 py-2 font-medium opacity-100"
          >
            Book Now
          </a>
        </li>
      </ul>

      <div className="flex items-center gap-4">
        <button
          onClick={openCart}
          className="relative text-cream hover:text-gold transition-colors"
          aria-label="Open cart"
        >
          <ShoppingBag size={20} />
          {count > 0 && (
            <span className="absolute -top-2 -right-2 bg-gold text-black text-[10px] font-medium w-5 h-5 rounded-full flex items-center justify-center">
              {count}
            </span>
          )}
        </button>
        <button
          className="md:hidden text-cream"
          onClick={() => setMobileOpen((o) => !o)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {mobileOpen && (
        <div className="absolute top-full left-0 right-0 bg-black flex flex-col gap-4 p-6 md:hidden">
          <Link href="/produtos" onClick={() => setMobileOpen(false)} className="nav-link">
            Collections
          </Link>
          <a href="/#why" onClick={() => setMobileOpen(false)} className="nav-link">
            Why Us
          </a>
          <a href="/#colour" onClick={() => setMobileOpen(false)} className="nav-link">
            Colours
          </a>
          <a href="/#accessories" onClick={() => setMobileOpen(false)} className="nav-link">
            Accessories
          </a>
          <a href="/#contact" onClick={() => setMobileOpen(false)} className="nav-link">
            Contact
          </a>
          <a
            href="https://wa.me/61450670239"
            target="_blank"
            rel="noopener noreferrer"
            className="text-gold"
          >
            Book Now
          </a>
        </div>
      )}

      <style>{`
        .nav-link{color:var(--cream);text-decoration:none;font-size:.75rem;letter-spacing:.2em;text-transform:uppercase;font-weight:400;opacity:.8;transition:opacity .2s}
        .nav-link:hover{opacity:1;color:var(--gold-light)}
      `}</style>
    </nav>
  );
}
