import Link from "next/link";
import Image from "next/image";
import { PRODUCTS } from "@/lib/products";
import ProductCard from "@/components/ProductCard";

const WA = "https://wa.me/61450670239";

const WHY_ITEMS = [
  {
    label: "100% Remy Human Hair",
    text: "Every strand is ethically sourced, cuticle-aligned Remy hair — the gold standard for longevity, softness and natural movement.",
  },
  {
    label: "Professional Salon Quality",
    text: "Applied by experienced technicians at our Bankstown salon — every set is installed with precision and care for your natural hair.",
  },
  {
    label: "Colour Matching Support",
    text: "Send us a photo and our specialists hand-select the perfect shade from our extensive library — guaranteed seamless blending.",
  },
  {
    label: "Australian Based",
    text: "Proudly Sydney-based with a physical salon in Bankstown NSW — come in for a consultation or order with confidence.",
  },
  {
    label: "WhatsApp Consultation",
    text: "Not sure where to start? Chat directly with our team for personalised recommendations — no commitment, no pressure.",
  },
  {
    label: "Fast Shipping",
    text: "Express dispatch on all in-stock items. We ship Australia-wide so your dream hair arrives quickly and beautifully packaged.",
  },
];

const ACCESSORIES = [
  {
    tag: "Adhesive",
    name: "Walker Tape Ultra Hold Adhesive",
    desc: "Maximum-strength hair system adhesive by Walker Tape. Brush-on applicator, 0.5 fl oz. Ideal for tape and weft installations.",
    image: "/products/img-09-40972b93.jpg",
  },
  {
    tag: "Kit",
    name: "Micro Ring Beads & Application Tool Kit",
    desc: "Complete kit with silicone-lined micro ring beads in multiple shades, loop pulling needles and wooden applicator tools for nano and micro ring installs.",
    image: "/products/img-10-ff87849e.jpg",
  },
  {
    tag: "Tape",
    name: "Walker Tape Lace Front Hair System Tape",
    desc: "Professional-grade double-sided hair system tape. Available in 3-yard and 36-yard rolls. Made in the USA.",
    image: "/products/img-11-6ea1e80d.jpg",
  },
  {
    tag: "Remover",
    name: "Lace Wig Bond & Toupee Tape Remover",
    desc: "Gentle yet effective solvent for removing lace wig bond and toupee tape adhesives. 30ml precision-tip bottle. Safe for scalp use.",
    image: "/products/img-12-f9ce8ef5.jpg",
  },
  {
    tag: "Micro Rings",
    name: "Silicone-Lined Micro Ring Beads",
    desc: "Available in shades #1, #3, #8, #11, #13 and more. Silicone lining protects the hair shaft. 500 beads per jar.",
    image: "/products/img-13-db2d9c75.jpg",
  },
  {
    tag: "Tape",
    name: "Walker Tape Ultra Hold Hair System Tape",
    desc: "12-yard roll of Ultra Hold double-sided hair system tape. Strong, waterproof hold. Made in the USA.",
    image: "/products/img-14-4c419ea2.jpg",
  },
  {
    tag: "Nano Rings",
    name: "Copper Nano Rings / Micro Tubes",
    desc: "2.8mm OD × 2.3mm ID × 7.0mm length. Available in shades #1, #3, #5, #6, #7, #8, #11, #13.",
    image: "/products/img-15-041e32e5.jpg",
  },
];

const HOURS = [
  ["Monday", "9:00 AM – 6:00 PM"],
  ["Tuesday", "Closed"],
  ["Wednesday", "9:00 AM – 6:00 PM"],
  ["Thursday", "9:00 AM – 8:00 PM"],
  ["Friday", "9:00 AM – 6:00 PM"],
  ["Saturday", "9:00 AM – 6:00 PM"],
  ["Sunday", "9:00 AM – 6:00 PM"],
];

export default function Home() {
  const categories = Array.from(
    new Map(PRODUCTS.map((p) => [p.category, p])).values()
  );

  return (
    <>
      {/* HERO */}
      <section className="relative min-h-[90vh] flex items-center bg-black overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/products/img-02-3c54041a.jpg"
            alt="Dé.Oscar Hair Extensions"
            fill
            priority
            className="object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-black/85 via-black/50 to-black/20" />
        </div>
        <div className="relative z-10 px-[8vw] max-w-[700px]">
          <p className="text-[0.7rem] tracking-[0.35em] uppercase text-gold mb-6">
            Sydney, Australia &middot; Premium Hair Extensions
          </p>
          <h1 className="font-serif text-[clamp(2.6rem,6vw,5rem)] text-white leading-[1.1] mb-6">
            Effortless Length.
            <br />
            <em className="italic text-gold-light">Undeniable Luxury.</em>
          </h1>
          <p className="text-white/70 leading-relaxed max-w-[480px] mb-10">
            Hand-selected 100% Remy human hair extensions crafted for women
            who refuse to compromise.
          </p>
          <div className="flex gap-4 flex-wrap">
            <a href="#collections" className="btn-primary">
              Shop Extensions
            </a>
            <a
              href={WA}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-outline !text-white !border-white/40"
            >
              WhatsApp Consultation
            </a>
          </div>
        </div>
      </section>

      {/* MARQUEE */}
      <div className="bg-gold py-3 overflow-hidden">
        <div className="flex gap-12 whitespace-nowrap animate-marquee">
          {Array(4)
            .fill(
              "100% Remy Human Hair · Professional Salon Quality · Sydney Based · Colour Matching Service · Clip In · Tape · Invisible Weft · Nano ·"
            )
            .map((t, i) => (
              <span
                key={i}
                className="text-[0.65rem] tracking-[0.25em] uppercase text-black font-medium"
              >
                {t}
              </span>
            ))}
        </div>
      </div>

      {/* COLLECTIONS */}
      <section id="collections" className="bg-black text-cream px-[8vw] py-24">
        <div className="text-center mb-16">
          <p className="section-eyebrow">Our Range</p>
          <h2 className="section-title text-cream text-[clamp(2rem,4vw,3.2rem)] mb-6">
            Four Methods.
            <br />
            One Standard.
          </h2>
          <p className="text-cream/55 text-sm max-w-[520px] mx-auto leading-relaxed">
            Each method is precision-applied by trained specialists, using
            only the finest 100% Remy human hair — seamlessly blended,
            invisibly beautiful.
          </p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-[1.5px] bg-gold/15">
          {categories.map((p) => (
            <Link
              key={p.category}
              href={`/produtos?categoria=${p.category}`}
              className="group bg-mid overflow-hidden"
            >
              <div className="relative aspect-[3/4] overflow-hidden">
                <Image
                  src={p.image}
                  alt={p.categoryLabel}
                  fill
                  sizes="(max-width:768px) 50vw, 16vw"
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                />
              </div>
              <div className="p-4">
                <p className="font-serif text-sm text-cream leading-tight">
                  {p.categoryLabel}
                </p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* BESTSELLERS */}
      <section className="px-[8vw] py-24 bg-cream">
        <div className="mb-12">
          <p className="section-eyebrow">Bestsellers</p>
          <h2 className="section-title text-[clamp(2rem,4vw,3.2rem)]">
            Customer favourites
          </h2>
          <div className="divider" />
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-px bg-gold/15">
          {PRODUCTS.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* WHY US */}
      <section id="why" className="bg-cream px-[8vw] py-24">
        <p className="section-eyebrow">The Dé.Oscar Difference</p>
        <h2 className="section-title text-[clamp(2rem,4vw,3.2rem)]">
          Why women choose
          <br />
          <em className="italic">Dé.Oscar.</em>
        </h2>
        <div className="divider" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 mt-12">
          {WHY_ITEMS.map((item) => (
            <div key={item.label} className="flex flex-col gap-4">
              <div className="w-11 h-11 flex items-center justify-center border border-gold text-gold">
                <div className="w-3 h-3 rounded-full bg-gold" />
              </div>
              <p className="font-serif text-lg">{item.label}</p>
              <p className="text-[0.8rem] text-text-light leading-relaxed">
                {item.text}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* COLOUR MATCHING */}
      <section id="colour" className="px-[8vw] py-24" style={{ background: "#1a1612" }}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-[5vw] items-center">
          <div className="grid grid-cols-2 gap-[3px]">
            <div className="col-span-2 relative aspect-[2/1]">
              <Image src="/products/img-06-634fe352.jpg" alt="Hair colour range" fill className="object-cover" />
            </div>
            <div className="relative aspect-square">
              <Image src="/products/img-07-aa2430d7.jpg" alt="Tape extension colours" fill className="object-cover" />
            </div>
            <div className="relative aspect-square">
              <Image src="/products/img-07-aa2430d7.jpg" alt="Nano extension colours" fill className="object-cover" />
            </div>
          </div>
          <div className="text-cream">
            <p className="section-eyebrow">Colour Matching</p>
            <h2 className="section-title text-[clamp(2rem,4vw,3.2rem)]">
              A shade for
              <br />
              every shade.
            </h2>
            <div className="divider" />
            <p className="text-cream/60 text-sm leading-loose mb-8">
              From jet black to platinum blonde, ash tones to warm caramels —
              our colour range is curated to blend with every natural hair
              colour. Our specialists provide personalised shade matching so
              your extensions look like they grew from your own scalp.
            </p>
            <div className="flex flex-col gap-4 items-start">
              <a
                href={`${WA}?text=Hi%2C+I'd+like+help+matching+my+hair+colour.`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-[0.75rem] tracking-widest uppercase text-cream hover:text-gold transition-colors before:content-[''] before:inline-block before:w-7 before:h-px before:bg-gold"
              >
                WhatsApp Colour Matching
              </a>
              <a
                href="https://www.instagram.com/de.oscarhairdresser/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-[0.75rem] tracking-widest uppercase text-cream hover:text-gold transition-colors before:content-[''] before:inline-block before:w-7 before:h-px before:bg-gold"
              >
                View Our Colour Gallery
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section className="bg-black px-[8vw] py-20 text-center">
        <p className="section-eyebrow text-gold">Transparent Pricing</p>
        <h2 className="section-title text-cream text-[clamp(2rem,4vw,3.2rem)] mb-12">
          Prices from $250 AUD
        </h2>
        <div className="relative max-w-[760px] mx-auto aspect-[4/3] rounded">
          <Image
            src="/products/img-08-9ce5356d.jpg"
            alt="Dé.Oscar Price Guide"
            fill
            className="object-contain rounded"
          />
        </div>
      </section>

      {/* WHATSAPP CTA */}
      <section id="consult" className="bg-black text-center px-[8vw] py-28 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(201,169,110,0.08)_0%,transparent_70%)]" />
        <div className="relative z-10">
          <p className="section-eyebrow text-gold">Your Journey Starts Here</p>
          <h2 className="section-title text-cream text-[clamp(2rem,5vw,4rem)] mb-4">
            Begin your <em className="italic text-gold-light">transformation.</em>
          </h2>
          <p className="text-cream/55 max-w-[520px] mx-auto mb-10 leading-relaxed">
            Chat with our specialists for personalised colour matching, length
            recommendations and styling guidance. No pressure — just expert
            advice, for free.
          </p>
          <a
            href={`${WA}?text=Hi%2C+I'd+like+to+book+a+hair+extension+consultation.`}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary"
          >
            Chat on WhatsApp
          </a>
        </div>
      </section>

      {/* ACCESSORIES */}
      <section id="accessories" className="bg-cream px-[8vw] py-24">
        <p className="section-eyebrow">Tools &amp; Supplies</p>
        <h2 className="section-title text-[clamp(2rem,4vw,3.2rem)]">
          Application <em className="italic">Accessories.</em>
        </h2>
        <div className="divider" />
        <p className="text-sm text-text-light leading-relaxed max-w-[560px] mb-14">
          Everything your technician needs for a flawless install. All
          accessories available from{" "}
          <strong className="text-black">AUD $10+</strong> — enquire via
          WhatsApp for pricing and availability.
        </p>

        <div className="flex gap-5 overflow-x-auto pb-5" style={{ scrollSnapType: "x mandatory" }}>
          {ACCESSORIES.map((a) => (
            <div
              key={a.name}
              className="bg-white shadow-[0_2px_20px_rgba(0,0,0,0.06)] min-w-[280px] max-w-[280px] flex-shrink-0"
              style={{ scrollSnapAlign: "start" }}
            >
              <div className="relative aspect-square">
                <Image src={a.image} alt={a.name} fill className="object-cover" />
              </div>
              <div className="p-6">
                <p className="text-[0.6rem] tracking-widest uppercase text-gold mb-1">
                  {a.tag}
                </p>
                <h3 className="font-serif text-lg mb-2">{a.name}</h3>
                <p className="text-[0.78rem] text-text-light leading-relaxed mb-5">
                  {a.desc}
                </p>
                <a
                  href={`${WA}?text=Hi%2C+I'd+like+to+order+${encodeURIComponent(a.name)}.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[0.65rem] tracking-widest uppercase text-gold border-b border-gold/40 pb-0.5"
                >
                  Enquire &rarr;
                </a>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12 p-8 bg-black max-w-[600px] mx-auto">
          <p className="font-serif text-xl text-cream mb-2">
            Need something not listed?
          </p>
          <p className="text-[0.8rem] text-cream/50 mb-6">
            Message us on WhatsApp — we stock a wide range of professional
            hair extension tools and supplies.
          </p>
          <a
            href={`${WA}?text=Hi%2C+I'd+like+to+enquire+about+accessories+and+tools.`}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary"
          >
            WhatsApp Us
          </a>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="bg-cream px-[8vw] py-24 grid grid-cols-1 md:grid-cols-2 gap-[5vw] items-start">
        <div>
          <p className="section-eyebrow">Get In Touch</p>
          <h2 className="font-serif text-4xl font-light mb-8">
            Visit Us in
            <br />
            Bankstown.
          </h2>
          <div className="divider" />
          <div className="flex flex-col gap-6">
            <div className="flex items-start gap-4 text-[0.85rem] text-text-light leading-relaxed">
              <div>
                <strong className="block font-serif text-base text-black mb-1 font-normal">
                  Salon Address
                </strong>
                11/324 Chapel Road, Bankstown NSW, Sydney, Australia
              </div>
            </div>
            <div className="flex items-start gap-4 text-[0.85rem] text-text-light leading-relaxed">
              <div>
                <strong className="block font-serif text-base text-black mb-1 font-normal">
                  Phone &amp; WhatsApp
                </strong>
                <a href="tel:0450670239" className="text-inherit no-underline">
                  0450 670 239
                </a>
              </div>
            </div>
            <div className="flex items-start gap-4 text-[0.85rem] text-text-light leading-relaxed">
              <div>
                <strong className="block font-serif text-base text-black mb-1 font-normal">
                  Instagram
                </strong>
                <a
                  href="https://www.instagram.com/de.oscarhairdresser/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-inherit no-underline"
                >
                  @de.oscarhairdresser
                </a>
              </div>
            </div>
          </div>
        </div>
        <div>
          <p className="section-eyebrow">Opening Hours</p>
          <h3 className="font-serif text-2xl font-light mb-6">
            When You Can
            <br />
            Find Us.
          </h3>
          <div className="divider" />
          <div className="grid gap-2 mb-8">
            {HOURS.map(([day, hours]) => (
              <div
                key={day}
                className="flex justify-between text-[0.8rem] pb-2 border-b border-black/[0.06]"
              >
                <span>{day}</span>
                <span className={hours === "Closed" ? "text-[#c94c4c]" : "text-text-light"}>
                  {hours}
                </span>
              </div>
            ))}
          </div>
          <a href={WA} target="_blank" rel="noopener noreferrer" className="btn-primary">
            Book via WhatsApp
          </a>
        </div>
      </section>

      {/* WHATSAPP FLOAT */}
      <a
        href={`${WA}?text=Hi%2C+I'd+like+to+enquire+about+hair+extensions.`}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="WhatsApp"
        className="fixed bottom-7 right-7 z-[200] w-12 h-12 bg-gold rounded-full flex items-center justify-center shadow-[0_4px_20px_rgba(201,169,110,0.4)] hover:scale-110 transition-transform"
      >
        <svg viewBox="0 0 24 24" fill="black" width="22" height="22">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z" />
        </svg>
      </a>

      <style>{`
        @keyframes marquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}
        .animate-marquee{animation:marquee 22s linear infinite}
      `}</style>
    </>
  );
}
